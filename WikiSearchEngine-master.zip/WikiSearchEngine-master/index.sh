#!/bin/bash   
python "./code/myindex.py" $1 $2

